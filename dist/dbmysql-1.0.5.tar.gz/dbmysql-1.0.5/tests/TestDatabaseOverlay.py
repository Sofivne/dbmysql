import unittest

from dbmysql import DatabaseOverlay




class TestDatabaseOverlay(unittest.TestCase):
    def setUp(self):
        # Mettez en place votre objet DatabaseOverlay pour les tests
        self.db = DatabaseOverlay()

    def tearDown(self):
        # Fermez la connexion après les tests
        self.db.close()

    def test_connection(self):
        # Testez la connexion à la base de données
        state, con = self.db.get_connect()
        self.assertTrue(state)
        self.assertIsNotNone(con)

    def test_insert(self):
        # Testez l'insertion de données dans la base de données
        table = "test_table"
        inner_sql = "'test_value'"
        new_id = self.db.insert(table, inner_sql)
        self.assertNotEqual(new_id, -1)

    # Ajoutez d'autres méthodes de test selon vos besoins

if __name__ == '__main__':
    unittest.main()
